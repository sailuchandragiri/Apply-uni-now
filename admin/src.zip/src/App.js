
import './App.css';
import Admin from './components/Admin';
import Login from './components/Login';
//import Login from './components/Login';


function App() {
  return (
    <div className='main'>
      
      <Admin/>
    </div>
  );
}
export default App;
